# Deployment Guide

## أفضل مكان لرفع الموقع
أنصح باستخدام:
1. Vercel (الأفضل لمشاريع Next.js)
2. Netlify

## خطوات الرفع على Vercel
1. ارفع المشروع على GitHub
2. افتح https://vercel.com
3. اختر New Project
4. اربط GitHub
5. اختر المشروع
6. اضغط Deploy

## مهم
- استخدم ملف `.env.example` كمرجع.
- لا ترفع أي مفاتيح سرية حقيقية داخل GitHub.

## أوامر التشغيل محليًا
```bash
npm install
npm run dev
```

## أوامر البناء
```bash
npm run build
```

