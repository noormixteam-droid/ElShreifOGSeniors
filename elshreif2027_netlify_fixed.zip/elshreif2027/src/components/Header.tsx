'use client';

import React, { useState, useEffect } from 'react';
import AppLogo from '@/components/ui/AppLogo';
import Link from 'next/link';

const NAV_LINKS = [
  { label: 'Gallery', href: '#gallery' },
  { label: 'Memories', href: '#memories' },
  { label: 'Connect', href: '#social' },
];

export default function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 60);
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    if (menuOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => { document.body.style.overflow = ''; };
  }, [menuOpen]);

  return (
    <>
      <header
        className="fixed top-0 left-0 w-full z-[100] transition-all duration-300 px-4 md:px-8 lg:px-12 py-4"
        style={scrolled ? {
          background: 'rgba(6, 16, 31, 0.92)',
          backdropFilter: 'blur(20px)',
          WebkitBackdropFilter: 'blur(20px)',
          borderBottom: '1px solid rgba(201, 168, 76, 0.12)',
        } : {
          background: 'transparent',
        }}
      >
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2 group">
            <AppLogo
              size={36}
              onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
              className="transition-transform duration-300 group-hover:scale-105"
            />
            <span
              className="font-display font-bold text-base tracking-tight hidden sm:block"
              style={{ color: 'var(--accent)' }}
            >
              ElShreif<span style={{ color: 'var(--foreground)' }}>2027</span>
            </span>
          </Link>

          {/* Desktop nav */}
          <nav className="hidden md:flex items-center gap-8">
            {NAV_LINKS.map((link) => (
              <a
                key={link.label}
                href={link.href}
                className="text-eyebrow transition-colors duration-200"
                style={{ color: 'var(--silver)' }}
                onMouseEnter={(e) => { (e.currentTarget as HTMLAnchorElement).style.color = 'var(--accent)'; }}
                onMouseLeave={(e) => { (e.currentTarget as HTMLAnchorElement).style.color = 'var(--silver)'; }}
              >
                {link.label}
              </a>
            ))}
            <a
              href="https://www.instagram.com/27elshreif"
              target="_blank"
              rel="noopener noreferrer"
              className="px-5 py-2 rounded-full text-xs font-semibold tracking-wide transition-all duration-200"
              style={{
                border: '1px solid rgba(201,168,76,0.4)',
                color: 'var(--accent)',
              }}
              onMouseEnter={(e) => {
                (e.currentTarget as HTMLAnchorElement).style.background = 'rgba(201,168,76,0.1)';
                (e.currentTarget as HTMLAnchorElement).style.borderColor = 'var(--accent)';
              }}
              onMouseLeave={(e) => {
                (e.currentTarget as HTMLAnchorElement).style.background = 'transparent';
                (e.currentTarget as HTMLAnchorElement).style.borderColor = 'rgba(201,168,76,0.4)';
              }}
            >
              @27elshreif
            </a>
          </nav>

          {/* Mobile hamburger */}
          <button
            className="md:hidden flex flex-col gap-1.5 p-2 z-[110]"
            onClick={() => setMenuOpen(!menuOpen)}
            aria-label={menuOpen ? 'Close menu' : 'Open menu'}
          >
            <span
              className="block w-6 h-0.5 transition-all duration-300"
              style={{
                background: 'var(--accent)',
                transform: menuOpen ? 'translateY(8px) rotate(45deg)' : 'none',
              }}
            />
            <span
              className="block w-6 h-0.5 transition-all duration-300"
              style={{
                background: 'var(--accent)',
                opacity: menuOpen ? 0 : 1,
              }}
            />
            <span
              className="block w-6 h-0.5 transition-all duration-300"
              style={{
                background: 'var(--accent)',
                transform: menuOpen ? 'translateY(-8px) rotate(-45deg)' : 'none',
              }}
            />
          </button>
        </div>
      </header>

      {/* Mobile menu overlay */}
      {menuOpen && (
        <div
          className="fixed inset-0 z-[99] flex flex-col items-center justify-center"
          style={{
            background: 'rgba(6, 16, 31, 0.97)',
            backdropFilter: 'blur(20px)',
          }}
        >
          <nav className="flex flex-col items-center gap-8">
            {NAV_LINKS.map((link) => (
              <a
                key={link.label}
                href={link.href}
                className="font-display font-bold text-3xl transition-colors duration-200"
                style={{ color: 'var(--foreground)' }}
                onClick={() => setMenuOpen(false)}
                onMouseEnter={(e) => { (e.currentTarget as HTMLAnchorElement).style.color = 'var(--accent)'; }}
                onMouseLeave={(e) => { (e.currentTarget as HTMLAnchorElement).style.color = 'var(--foreground)'; }}
              >
                {link.label}
              </a>
            ))}
            <a
              href="https://www.instagram.com/27elshreif"
              target="_blank"
              rel="noopener noreferrer"
              className="mt-4 px-8 py-3 rounded-full font-semibold text-sm transition-all duration-200"
              style={{
                background: 'linear-gradient(135deg, var(--gold-dark), var(--accent))',
                color: 'var(--accent-foreground)',
              }}
              onClick={() => setMenuOpen(false)}
            >
              @27elshreif
            </a>
          </nav>
        </div>
      )}
    </>
  );
}