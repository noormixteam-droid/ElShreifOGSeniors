'use client';

import React from 'react';
import AppLogo from '@/components/ui/AppLogo';
import Link from 'next/link';

export default function Footer() {
  return (
    <footer
      className="py-10 px-4 md:px-8"
      style={{ borderTop: '1px solid rgba(201, 168, 76, 0.1)' }}
    >
      <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
        {/* Logo + brand */}
        <Link href="/" className="flex items-center gap-2">
          <AppLogo size={28} />
          <span className="font-display font-bold text-sm" style={{ color: 'var(--accent)' }}>
            ElShreif<span style={{ color: 'var(--muted-foreground)' }}>2027</span>
          </span>
        </Link>

        {/* Copyright */}
        <p className="text-xs font-medium" style={{ color: 'var(--muted-foreground)', letterSpacing: '0.05em' }}>
          © 2027 Senior Class El Shreif. All rights reserved.
        </p>

        {/* Links */}
        <div className="flex items-center gap-6">
          <a
            href="https://www.instagram.com/27elshreif"
            target="_blank"
            rel="noopener noreferrer"
            className="text-xs font-medium transition-colors duration-200"
            style={{ color: 'var(--muted-foreground)' }}
            onMouseEnter={(e) => { (e.currentTarget as HTMLAnchorElement).style.color = 'var(--accent)'; }}
            onMouseLeave={(e) => { (e.currentTarget as HTMLAnchorElement).style.color = 'var(--muted-foreground)'; }}
          >
            Instagram
          </a>
          <a
            href="#gallery"
            className="text-xs font-medium transition-colors duration-200"
            style={{ color: 'var(--muted-foreground)' }}
            onMouseEnter={(e) => { (e.currentTarget as HTMLAnchorElement).style.color = 'var(--accent)'; }}
            onMouseLeave={(e) => { (e.currentTarget as HTMLAnchorElement).style.color = 'var(--muted-foreground)'; }}
          >
            Gallery
          </a>
          <a
            href="#memories"
            className="text-xs font-medium transition-colors duration-200"
            style={{ color: 'var(--muted-foreground)' }}
            onMouseEnter={(e) => { (e.currentTarget as HTMLAnchorElement).style.color = 'var(--accent)'; }}
            onMouseLeave={(e) => { (e.currentTarget as HTMLAnchorElement).style.color = 'var(--muted-foreground)'; }}
          >
            Memories
          </a>
        </div>
      </div>
    </footer>
  );
}