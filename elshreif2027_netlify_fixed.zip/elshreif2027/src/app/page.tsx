import React from 'react';
import HeroSection from './components/HeroSection';
import GallerySection from './components/GallerySection';
import MemoriesSection from './components/MemoriesSection';
import SocialSection from './components/SocialSection';
import Footer from '@/components/Footer';
import Header from '@/components/Header';

export default function HomePage() {
  return (
    <main className="relative overflow-x-hidden" style={{ background: 'var(--background)' }}>
      <Header />
      <HeroSection />
      <GallerySection />
      <MemoriesSection />
      <SocialSection />
      <Footer />
    </main>
  );
}