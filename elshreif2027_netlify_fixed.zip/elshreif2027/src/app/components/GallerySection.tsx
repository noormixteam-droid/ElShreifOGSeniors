'use client';

import React, { useEffect, useRef, useState, useCallback } from 'react';
import AppImage from '@/components/ui/AppImage';

interface GalleryImage {
  id: number;
  src: string;
  alt: string;
  colSpan?: number;
  rowSpan?: number;
}

const GALLERY_IMAGES: GalleryImage[] = [
{
  id: 1,
  src: "https://images.unsplash.com/photo-1675410163638-f6a348ebc500",
  alt: 'Graduates in dark academic robes celebrating outdoors, golden afternoon light, joyful group moment',
  colSpan: 1,
  rowSpan: 2
},
{
  id: 2,
  src: "https://img.rocket.new/generatedImages/rocket_gen_img_16f0a7c4f-1767598161338.png",
  alt: 'Graduate tossing mortarboard cap into bright blue sky, celebratory outdoor ceremony',
  colSpan: 2,
  rowSpan: 1
},
{
  id: 3,
  src: "https://images.unsplash.com/photo-1591657137431-591c39c00ffa",
  alt: 'Group of graduates laughing together in formal attire, warm sunlit campus background',
  colSpan: 1,
  rowSpan: 1
},
{
  id: 4,
  src: "https://img.rocket.new/generatedImages/rocket_gen_img_1408ee11c-1768731442770.png",
  alt: 'Students in classroom celebrating with diplomas raised, festive academic atmosphere',
  colSpan: 1,
  rowSpan: 1
},
{
  id: 5,
  src: "https://images.unsplash.com/photo-1727465660831-c21323d23e5e",
  alt: 'Open books on wooden desk with warm study lamp, late night study session atmosphere',
  colSpan: 1,
  rowSpan: 1
},
{
  id: 6,
  src: "https://images.unsplash.com/photo-1707467337118-9b08b78a0c8c",
  alt: 'Young graduate smiling confidently holding diploma, formal attire, bright well-lit studio background',
  colSpan: 1,
  rowSpan: 1
},
{
  id: 7,
  src: "https://img.rocket.new/generatedImages/rocket_gen_img_1490396ad-1778350356820.png",
  alt: 'Group of students on campus steps wearing academic gowns, celebratory atmosphere, daytime',
  colSpan: 2,
  rowSpan: 1
},
{
  id: 8,
  src: "https://images.unsplash.com/photo-1590012314607-cda9d9b699ae",
  alt: 'Graduation ceremony hall with rows of seated graduates in caps and gowns, grand auditorium',
  colSpan: 1,
  rowSpan: 2
},
{
  id: 9,
  src: "https://img.rocket.new/generatedImages/rocket_gen_img_109145888-1773615811584.png",
  alt: 'Students studying together at library table with books and laptops, collaborative learning session',
  colSpan: 1,
  rowSpan: 1
},
{
  id: 10,
  src: "https://img.rocket.new/generatedImages/rocket_gen_img_198d174ef-1772820034745.png",
  alt: 'Friends laughing together outdoors on campus lawn, casual and joyful student life moment',
  colSpan: 1,
  rowSpan: 1
},
{
  id: 11,
  src: "https://images.unsplash.com/photo-1543365272-a116a6615f1a",
  alt: 'Graduates forming a circle viewed from above, caps and gowns creating geometric pattern',
  colSpan: 1,
  rowSpan: 1
},
{
  id: 12,
  src: "https://images.unsplash.com/photo-1672839416501-3100a66fcd6a",
  alt: 'Graduation cap and diploma on dark velvet background, golden tassel detail, ceremonial close-up',
  colSpan: 1,
  rowSpan: 1
}];


export default function GallerySection() {
  const sectionRef = useRef<HTMLElement>(null);
  const [lightbox, setLightbox] = useState<{open: boolean;index: number;}>({ open: false, index: 0 });
  const cardRefs = useRef<(HTMLDivElement | null)[]>([]);

  const openLightbox = useCallback((index: number) => {
    setLightbox({ open: true, index });
    document.body.style.overflow = 'hidden';
  }, []);

  const closeLightbox = useCallback(() => {
    setLightbox({ open: false, index: 0 });
    document.body.style.overflow = '';
  }, []);

  const prevImage = useCallback(() => {
    setLightbox((prev) => ({
      ...prev,
      index: (prev.index - 1 + GALLERY_IMAGES.length) % GALLERY_IMAGES.length
    }));
  }, []);

  const nextImage = useCallback(() => {
    setLightbox((prev) => ({
      ...prev,
      index: (prev.index + 1) % GALLERY_IMAGES.length
    }));
  }, []);

  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if (!lightbox.open) return;
      if (e.key === 'Escape') closeLightbox();
      if (e.key === 'ArrowLeft') prevImage();
      if (e.key === 'ArrowRight') nextImage();
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [lightbox.open, closeLightbox, prevImage, nextImage]);

  useEffect(() => {
    const initGsap = async () => {
      const { gsap: gsapLib } = await import('gsap');
      const { ScrollTrigger: ScrollTriggerPlugin } = await import('gsap/ScrollTrigger');
      gsapLib.registerPlugin(ScrollTriggerPlugin);

      cardRefs.current.forEach((card, i) => {
        if (!card) return;
        gsapLib.fromTo(
          card,
          { opacity: 0, y: 60, scale: 0.95 },
          {
            opacity: 1,
            y: 0,
            scale: 1,
            duration: 0.9,
            ease: 'power3.out',
            delay: i % 4 * 0.1,
            scrollTrigger: {
              trigger: card,
              start: 'top 88%',
              toggleActions: 'play none none none'
            }
          }
        );
      });
    };

    initGsap();
  }, []);

  return (
    <section
      id="gallery"
      ref={sectionRef}
      className="relative py-20 px-4 md:px-8 lg:px-12"
      style={{ background: 'linear-gradient(180deg, #06101f 0%, #080f1e 50%, #06101f 100%)' }}>
      
      {/* Section header */}
      <div className="max-w-7xl mx-auto mb-14">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
          <div>
            <span className="text-eyebrow block mb-3" style={{ color: 'var(--accent)' }}>
              ✦ Our Memories
            </span>
            <h2
              className="font-display font-bold text-section-title"
              style={{ color: 'var(--foreground)', lineHeight: 1.1 }}>
              
              The Gallery
            </h2>
          </div>
          <p className="max-w-sm text-base font-light" style={{ color: 'var(--muted-foreground)', lineHeight: 1.7 }}>
            Every frame holds a memory. Every smile tells a story. This is us — Senior 2027.
          </p>
        </div>
        {/* Gold divider */}
        <div
          className="mt-8 h-px w-full"
          style={{ background: 'linear-gradient(90deg, var(--accent), rgba(201,168,76,0.1))' }} />
        
      </div>

      {/* BENTO GRID AUDIT:
          Array: 12 cards
          Row 1: [col-1: Photo1 cs-1 rs-2] [col-2-3: Photo2 cs-2 rs-1] [col-4: Photo3 cs-1 rs-1]
          Row 2: [col-1: FILLED(Photo1)] [col-2: Photo4 cs-1] [col-3: Photo5 cs-1] [col-4: Photo6 cs-1]
          Row 3: [col-1-2: Photo7 cs-2 rs-1] [col-3: Photo8 cs-1 rs-2] [col-4: Photo9 cs-1]
          Row 4: [col-1: Photo10 cs-1] [col-2: Photo11 cs-1] [col-3: FILLED(Photo8)] [col-4: Photo12 cs-1]
          Placed: 12/12 ✓
         */}
      <div
        className="max-w-7xl mx-auto grid gap-3 md:gap-4"
        style={{
          gridTemplateColumns: 'repeat(4, 1fr)',
          gridTemplateRows: 'auto'
        }}>
        
        {/* Photo1 — col-1, row-span-2 */}
        <div
          ref={(el) => {cardRefs.current[0] = el;}}
          className="gallery-card rounded-xl md:rounded-2xl opacity-100"
          style={{ gridColumn: '1 / 2', gridRow: '1 / 3', minHeight: '300px' }}
          onClick={() => openLightbox(0)}
          role="button"
          tabIndex={0}
          onKeyDown={(e) => e.key === 'Enter' && openLightbox(0)}
          aria-label="Open gallery image 1">
          
          <AppImage
            src={GALLERY_IMAGES[0].src}
            alt={GALLERY_IMAGES[0].alt}
            fill
            sizes="(max-width: 768px) 50vw, 25vw"
            className="object-cover" />
          
          <div className="gallery-overlay-icon">
            <div className="w-12 h-12 rounded-full flex items-center justify-center" style={{ background: 'rgba(201,168,76,0.2)', border: '1px solid var(--accent)' }}>
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" style={{ color: 'var(--accent)' }}><circle cx="11" cy="11" r="8" /><path d="m21 21-4.35-4.35" /><path d="M11 8v6M8 11h6" /></svg>
            </div>
          </div>
        </div>

        {/* Photo2 — col-2-3, row-1 */}
        <div
          ref={(el) => {cardRefs.current[1] = el;}}
          className="gallery-card rounded-xl md:rounded-2xl opacity-100"
          style={{ gridColumn: '2 / 4', gridRow: '1 / 2', minHeight: '200px' }}
          onClick={() => openLightbox(1)}
          role="button"
          tabIndex={0}
          onKeyDown={(e) => e.key === 'Enter' && openLightbox(1)}
          aria-label="Open gallery image 2">
          
          <AppImage src={GALLERY_IMAGES[1].src} alt={GALLERY_IMAGES[1].alt} fill sizes="(max-width: 768px) 100vw, 50vw" className="object-cover" />
          <div className="gallery-overlay-icon">
            <div className="w-12 h-12 rounded-full flex items-center justify-center" style={{ background: 'rgba(201,168,76,0.2)', border: '1px solid var(--accent)' }}>
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" style={{ color: 'var(--accent)' }}><circle cx="11" cy="11" r="8" /><path d="m21 21-4.35-4.35" /><path d="M11 8v6M8 11h6" /></svg>
            </div>
          </div>
        </div>

        {/* Photo3 — col-4, row-1 */}
        <div
          ref={(el) => {cardRefs.current[2] = el;}}
          className="gallery-card rounded-xl md:rounded-2xl opacity-100"
          style={{ gridColumn: '4 / 5', gridRow: '1 / 2', minHeight: '200px' }}
          onClick={() => openLightbox(2)}
          role="button"
          tabIndex={0}
          onKeyDown={(e) => e.key === 'Enter' && openLightbox(2)}
          aria-label="Open gallery image 3">
          
          <AppImage src={GALLERY_IMAGES[2].src} alt={GALLERY_IMAGES[2].alt} fill sizes="(max-width: 768px) 50vw, 25vw" className="object-cover" />
          <div className="gallery-overlay-icon">
            <div className="w-12 h-12 rounded-full flex items-center justify-center" style={{ background: 'rgba(201,168,76,0.2)', border: '1px solid var(--accent)' }}>
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" style={{ color: 'var(--accent)' }}><circle cx="11" cy="11" r="8" /><path d="m21 21-4.35-4.35" /><path d="M11 8v6M8 11h6" /></svg>
            </div>
          </div>
        </div>

        {/* Photo4 — col-2, row-2 */}
        <div
          ref={(el) => {cardRefs.current[3] = el;}}
          className="gallery-card rounded-xl md:rounded-2xl opacity-100"
          style={{ gridColumn: '2 / 3', gridRow: '2 / 3', minHeight: '200px' }}
          onClick={() => openLightbox(3)}
          role="button"
          tabIndex={0}
          onKeyDown={(e) => e.key === 'Enter' && openLightbox(3)}
          aria-label="Open gallery image 4">
          
          <AppImage src={GALLERY_IMAGES[3].src} alt={GALLERY_IMAGES[3].alt} fill sizes="(max-width: 768px) 50vw, 25vw" className="object-cover" />
          <div className="gallery-overlay-icon">
            <div className="w-12 h-12 rounded-full flex items-center justify-center" style={{ background: 'rgba(201,168,76,0.2)', border: '1px solid var(--accent)' }}>
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" style={{ color: 'var(--accent)' }}><circle cx="11" cy="11" r="8" /><path d="m21 21-4.35-4.35" /><path d="M11 8v6M8 11h6" /></svg>
            </div>
          </div>
        </div>

        {/* Photo5 — col-3, row-2 */}
        <div
          ref={(el) => {cardRefs.current[4] = el;}}
          className="gallery-card rounded-xl md:rounded-2xl opacity-100"
          style={{ gridColumn: '3 / 4', gridRow: '2 / 3', minHeight: '200px' }}
          onClick={() => openLightbox(4)}
          role="button"
          tabIndex={0}
          onKeyDown={(e) => e.key === 'Enter' && openLightbox(4)}
          aria-label="Open gallery image 5">
          
          <AppImage src={GALLERY_IMAGES[4].src} alt={GALLERY_IMAGES[4].alt} fill sizes="(max-width: 768px) 50vw, 25vw" className="object-cover" />
          <div className="gallery-overlay-icon">
            <div className="w-12 h-12 rounded-full flex items-center justify-center" style={{ background: 'rgba(201,168,76,0.2)', border: '1px solid var(--accent)' }}>
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" style={{ color: 'var(--accent)' }}><circle cx="11" cy="11" r="8" /><path d="m21 21-4.35-4.35" /><path d="M11 8v6M8 11h6" /></svg>
            </div>
          </div>
        </div>

        {/* Photo6 — col-4, row-2 */}
        <div
          ref={(el) => {cardRefs.current[5] = el;}}
          className="gallery-card rounded-xl md:rounded-2xl opacity-100"
          style={{ gridColumn: '4 / 5', gridRow: '2 / 3', minHeight: '200px' }}
          onClick={() => openLightbox(5)}
          role="button"
          tabIndex={0}
          onKeyDown={(e) => e.key === 'Enter' && openLightbox(5)}
          aria-label="Open gallery image 6">
          
          <AppImage src={GALLERY_IMAGES[5].src} alt={GALLERY_IMAGES[5].alt} fill sizes="(max-width: 768px) 50vw, 25vw" className="object-cover" />
          <div className="gallery-overlay-icon">
            <div className="w-12 h-12 rounded-full flex items-center justify-center" style={{ background: 'rgba(201,168,76,0.2)', border: '1px solid var(--accent)' }}>
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" style={{ color: 'var(--accent)' }}><circle cx="11" cy="11" r="8" /><path d="m21 21-4.35-4.35" /><path d="M11 8v6M8 11h6" /></svg>
            </div>
          </div>
        </div>

        {/* Photo7 — col-1-2, row-3 */}
        <div
          ref={(el) => {cardRefs.current[6] = el;}}
          className="gallery-card rounded-xl md:rounded-2xl opacity-100"
          style={{ gridColumn: '1 / 3', gridRow: '3 / 4', minHeight: '220px' }}
          onClick={() => openLightbox(6)}
          role="button"
          tabIndex={0}
          onKeyDown={(e) => e.key === 'Enter' && openLightbox(6)}
          aria-label="Open gallery image 7">
          
          <AppImage src={GALLERY_IMAGES[6].src} alt={GALLERY_IMAGES[6].alt} fill sizes="(max-width: 768px) 100vw, 50vw" className="object-cover" />
          <div className="gallery-overlay-icon">
            <div className="w-12 h-12 rounded-full flex items-center justify-center" style={{ background: 'rgba(201,168,76,0.2)', border: '1px solid var(--accent)' }}>
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" style={{ color: 'var(--accent)' }}><circle cx="11" cy="11" r="8" /><path d="m21 21-4.35-4.35" /><path d="M11 8v6M8 11h6" /></svg>
            </div>
          </div>
        </div>

        {/* Photo8 — col-3, row-3-4 */}
        <div
          ref={(el) => {cardRefs.current[7] = el;}}
          className="gallery-card rounded-xl md:rounded-2xl opacity-100"
          style={{ gridColumn: '3 / 4', gridRow: '3 / 5', minHeight: '300px' }}
          onClick={() => openLightbox(7)}
          role="button"
          tabIndex={0}
          onKeyDown={(e) => e.key === 'Enter' && openLightbox(7)}
          aria-label="Open gallery image 8">
          
          <AppImage src={GALLERY_IMAGES[7].src} alt={GALLERY_IMAGES[7].alt} fill sizes="(max-width: 768px) 50vw, 25vw" className="object-cover" />
          <div className="gallery-overlay-icon">
            <div className="w-12 h-12 rounded-full flex items-center justify-center" style={{ background: 'rgba(201,168,76,0.2)', border: '1px solid var(--accent)' }}>
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" style={{ color: 'var(--accent)' }}><circle cx="11" cy="11" r="8" /><path d="m21 21-4.35-4.35" /><path d="M11 8v6M8 11h6" /></svg>
            </div>
          </div>
        </div>

        {/* Photo9 — col-4, row-3 */}
        <div
          ref={(el) => {cardRefs.current[8] = el;}}
          className="gallery-card rounded-xl md:rounded-2xl opacity-100"
          style={{ gridColumn: '4 / 5', gridRow: '3 / 4', minHeight: '220px' }}
          onClick={() => openLightbox(8)}
          role="button"
          tabIndex={0}
          onKeyDown={(e) => e.key === 'Enter' && openLightbox(8)}
          aria-label="Open gallery image 9">
          
          <AppImage src={GALLERY_IMAGES[8].src} alt={GALLERY_IMAGES[8].alt} fill sizes="(max-width: 768px) 50vw, 25vw" className="object-cover" />
          <div className="gallery-overlay-icon">
            <div className="w-12 h-12 rounded-full flex items-center justify-center" style={{ background: 'rgba(201,168,76,0.2)', border: '1px solid var(--accent)' }}>
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" style={{ color: 'var(--accent)' }}><circle cx="11" cy="11" r="8" /><path d="m21 21-4.35-4.35" /><path d="M11 8v6M8 11h6" /></svg>
            </div>
          </div>
        </div>

        {/* Photo10 — col-1, row-4 */}
        <div
          ref={(el) => {cardRefs.current[9] = el;}}
          className="gallery-card rounded-xl md:rounded-2xl opacity-100"
          style={{ gridColumn: '1 / 2', gridRow: '4 / 5', minHeight: '220px' }}
          onClick={() => openLightbox(9)}
          role="button"
          tabIndex={0}
          onKeyDown={(e) => e.key === 'Enter' && openLightbox(9)}
          aria-label="Open gallery image 10">
          
          <AppImage src={GALLERY_IMAGES[9].src} alt={GALLERY_IMAGES[9].alt} fill sizes="(max-width: 768px) 50vw, 25vw" className="object-cover" />
          <div className="gallery-overlay-icon">
            <div className="w-12 h-12 rounded-full flex items-center justify-center" style={{ background: 'rgba(201,168,76,0.2)', border: '1px solid var(--accent)' }}>
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" style={{ color: 'var(--accent)' }}><circle cx="11" cy="11" r="8" /><path d="m21 21-4.35-4.35" /><path d="M11 8v6M8 11h6" /></svg>
            </div>
          </div>
        </div>

        {/* Photo11 — col-2, row-4 */}
        <div
          ref={(el) => {cardRefs.current[10] = el;}}
          className="gallery-card rounded-xl md:rounded-2xl opacity-100"
          style={{ gridColumn: '2 / 3', gridRow: '4 / 5', minHeight: '220px' }}
          onClick={() => openLightbox(10)}
          role="button"
          tabIndex={0}
          onKeyDown={(e) => e.key === 'Enter' && openLightbox(10)}
          aria-label="Open gallery image 11">
          
          <AppImage src={GALLERY_IMAGES[10].src} alt={GALLERY_IMAGES[10].alt} fill sizes="(max-width: 768px) 50vw, 25vw" className="object-cover" />
          <div className="gallery-overlay-icon">
            <div className="w-12 h-12 rounded-full flex items-center justify-center" style={{ background: 'rgba(201,168,76,0.2)', border: '1px solid var(--accent)' }}>
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" style={{ color: 'var(--accent)' }}><circle cx="11" cy="11" r="8" /><path d="m21 21-4.35-4.35" /><path d="M11 8v6M8 11h6" /></svg>
            </div>
          </div>
        </div>

        {/* Photo12 — col-4, row-4 */}
        <div
          ref={(el) => {cardRefs.current[11] = el;}}
          className="gallery-card rounded-xl md:rounded-2xl opacity-100"
          style={{ gridColumn: '4 / 5', gridRow: '4 / 5', minHeight: '220px' }}
          onClick={() => openLightbox(11)}
          role="button"
          tabIndex={0}
          onKeyDown={(e) => e.key === 'Enter' && openLightbox(11)}
          aria-label="Open gallery image 12">
          
          <AppImage src={GALLERY_IMAGES[11].src} alt={GALLERY_IMAGES[11].alt} fill sizes="(max-width: 768px) 50vw, 25vw" className="object-cover" />
          <div className="gallery-overlay-icon">
            <div className="w-12 h-12 rounded-full flex items-center justify-center" style={{ background: 'rgba(201,168,76,0.2)', border: '1px solid var(--accent)' }}>
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" style={{ color: 'var(--accent)' }}><circle cx="11" cy="11" r="8" /><path d="m21 21-4.35-4.35" /><path d="M11 8v6M8 11h6" /></svg>
            </div>
          </div>
        </div>
      </div>

      {/* Lightbox */}
      {lightbox.open &&
      <div
        className="lightbox-backdrop"
        onClick={closeLightbox}
        role="dialog"
        aria-modal="true"
        aria-label="Image lightbox">
        
          <div
          className="relative w-full max-w-4xl mx-4"
          onClick={(e) => e.stopPropagation()}>
          
            {/* Close button */}
            <button
            onClick={closeLightbox}
            className="absolute -top-12 right-0 w-10 h-10 flex items-center justify-center rounded-full transition-all duration-200 z-10"
            style={{ border: '1px solid rgba(201,168,76,0.3)', color: 'var(--silver)' }}
            aria-label="Close lightbox"
            onMouseEnter={(e) => {
              (e.currentTarget as HTMLButtonElement).style.borderColor = 'var(--accent)';
              (e.currentTarget as HTMLButtonElement).style.color = 'var(--accent)';
            }}
            onMouseLeave={(e) => {
              (e.currentTarget as HTMLButtonElement).style.borderColor = 'rgba(201,168,76,0.3)';
              (e.currentTarget as HTMLButtonElement).style.color = 'var(--silver)';
            }}>
            
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M18 6 6 18M6 6l12 12" /></svg>
            </button>

            {/* Image container */}
            <div className="relative rounded-2xl overflow-hidden" style={{ maxHeight: '80vh' }}>
              <AppImage
              src={GALLERY_IMAGES[lightbox.index].src}
              alt={GALLERY_IMAGES[lightbox.index].alt}
              width={900}
              height={600}
              className="w-full object-contain"
              style={{ maxHeight: '80vh' }}
              priority />
            
            </div>

            {/* Navigation */}
            <div className="flex items-center justify-between mt-4">
              <button
              onClick={prevImage}
              className="flex items-center gap-2 px-5 py-2 rounded-full text-sm font-medium transition-all duration-200"
              style={{ border: '1px solid rgba(201,168,76,0.3)', color: 'var(--silver)' }}
              aria-label="Previous image"
              onMouseEnter={(e) => {
                (e.currentTarget as HTMLButtonElement).style.borderColor = 'var(--accent)';
                (e.currentTarget as HTMLButtonElement).style.color = 'var(--accent)';
              }}
              onMouseLeave={(e) => {
                (e.currentTarget as HTMLButtonElement).style.borderColor = 'rgba(201,168,76,0.3)';
                (e.currentTarget as HTMLButtonElement).style.color = 'var(--silver)';
              }}>
              
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M15 18l-6-6 6-6" /></svg>
                Prev
              </button>

              <span className="text-eyebrow" style={{ color: 'var(--muted-foreground)' }}>
                {lightbox.index + 1} / {GALLERY_IMAGES.length}
              </span>

              <button
              onClick={nextImage}
              className="flex items-center gap-2 px-5 py-2 rounded-full text-sm font-medium transition-all duration-200"
              style={{ border: '1px solid rgba(201,168,76,0.3)', color: 'var(--silver)' }}
              aria-label="Next image"
              onMouseEnter={(e) => {
                (e.currentTarget as HTMLButtonElement).style.borderColor = 'var(--accent)';
                (e.currentTarget as HTMLButtonElement).style.color = 'var(--accent)';
              }}
              onMouseLeave={(e) => {
                (e.currentTarget as HTMLButtonElement).style.borderColor = 'rgba(201,168,76,0.3)';
                (e.currentTarget as HTMLButtonElement).style.color = 'var(--silver)';
              }}>
              
                Next
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M9 18l6-6-6-6" /></svg>
              </button>
            </div>
          </div>
        </div>
      }

      {/* Mobile grid (2 cols) */}
      <style>{`
        @media (max-width: 767px) {
          #gallery-grid {
            grid-template-columns: repeat(2, 1fr) !important;
          }
          #gallery-grid > div {
            grid-column: auto !important;
            grid-row: auto !important;
            min-height: 160px !important;
          }
        }
      `}</style>
    </section>);

}