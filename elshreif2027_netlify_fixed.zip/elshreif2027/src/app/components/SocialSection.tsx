'use client';

import React, { useRef, useEffect } from 'react';

const SOCIAL_LINKS = [
  {
    name: 'Instagram',
    href: 'https://www.instagram.com/27elshreif',
    ariaLabel: 'Follow @27elshreif on Instagram',
    icon: (
      <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
        <rect width="20" height="20" x="2" y="2" rx="5" ry="5"/>
        <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/>
        <line x1="17.5" x2="17.51" y1="6.5" y2="6.5"/>
      </svg>
    ),
  },
  {
    name: 'TikTok',
    href: 'https://www.instagram.com/27elshreif',
    ariaLabel: 'Find us on TikTok',
    icon: (
      <svg width="22" height="22" viewBox="0 0 24 24" fill="currentColor">
        <path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-2.88 2.5 2.89 2.89 0 0 1-2.89-2.89 2.89 2.89 0 0 1 2.89-2.89c.28 0 .54.04.79.1V9.01a6.32 6.32 0 0 0-.79-.05 6.34 6.34 0 0 0-6.34 6.34 6.34 6.34 0 0 0 6.34 6.34 6.34 6.34 0 0 0 6.34-6.34V8.69a8.27 8.27 0 0 0 4.83 1.55V6.79a4.85 4.85 0 0 1-1.07-.1z"/>
      </svg>
    ),
  },
  {
    name: 'Facebook',
    href: 'https://www.instagram.com/27elshreif',
    ariaLabel: 'Find us on Facebook',
    icon: (
      <svg width="22" height="22" viewBox="0 0 24 24" fill="currentColor">
        <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/>
      </svg>
    ),
  },
];

export default function SocialSection() {
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const initGsap = async () => {
      const { gsap } = await import('gsap');
      const { ScrollTrigger } = await import('gsap/ScrollTrigger');
      gsap.registerPlugin(ScrollTrigger);

      if (!sectionRef.current) return;

      gsap.fromTo(
        sectionRef.current.querySelectorAll('.social-reveal'),
        { opacity: 0, y: 40 },
        {
          opacity: 1,
          y: 0,
          stagger: 0.12,
          duration: 1.0,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 80%',
          },
        }
      );
    };
    initGsap();
  }, []);

  return (
    <section
      id="social"
      ref={sectionRef}
      className="relative py-20 px-4 md:px-8 overflow-hidden"
      style={{ background: 'linear-gradient(180deg, #06101f 0%, #0a1628 100%)' }}
    >
      {/* Atmospheric glow */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background: 'radial-gradient(ellipse 70% 50% at 50% 50%, rgba(201,168,76,0.06) 0%, transparent 70%)',
        }}
      />

      <div className="max-w-2xl mx-auto text-center relative z-10">
        {/* Circular badge (small) */}
        <div className="social-reveal flex justify-center mb-10">
          <svg
            viewBox="0 0 120 120"
            style={{ width: '90px', height: '90px' }}
            aria-hidden="true"
          >
            <defs>
              <linearGradient id="goldGradSocial" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#A07830" />
                <stop offset="50%" stopColor="#E8C870" />
                <stop offset="100%" stopColor="#C9A84C" />
              </linearGradient>
            </defs>
            <circle cx="60" cy="60" r="56" fill="none" stroke="url(#goldGradSocial)" strokeWidth="1" opacity="0.5" />
            <circle cx="60" cy="60" r="50" fill="rgba(10,22,40,0.8)" stroke="url(#goldGradSocial)" strokeWidth="1.5" />
            <text x="60" y="55" textAnchor="middle" fill="#C9A84C" fontSize="18" fontFamily="var(--font-fraunces)" fontWeight="700">27</text>
            <text x="60" y="70" textAnchor="middle" fill="#B8C4D0" fontSize="7" fontFamily="var(--font-dm-sans)" fontWeight="600" letterSpacing="2">EL SHREIF</text>
          </svg>
        </div>

        <span className="social-reveal text-eyebrow block mb-4" style={{ color: 'var(--accent)' }}>
          ✦ Stay Connected
        </span>

        <h2
          className="social-reveal font-display font-bold text-section-title mb-4"
          style={{ color: 'var(--foreground)', lineHeight: 1.1 }}
        >
          Follow Our Journey
        </h2>

        <p
          className="social-reveal text-base font-light mb-10 max-w-md mx-auto"
          style={{ color: 'var(--muted-foreground)', lineHeight: 1.7 }}
        >
          Follow us on Instagram for more memories, updates, and celebrations from the class of 2027.
        </p>

        {/* Primary Instagram CTA */}
        <div className="social-reveal mb-10">
          <a
            href="https://www.instagram.com/27elshreif"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-3 px-8 py-4 rounded-full font-semibold text-base transition-all duration-300"
            style={{
              background: 'linear-gradient(135deg, #833AB4 0%, #C13584 40%, #E1306C 70%, #FD1D1D 100%)',
              color: '#ffffff',
              boxShadow: '0 4px 24px rgba(193, 53, 132, 0.35)',
            }}
            onMouseEnter={(e) => {
              (e.currentTarget as HTMLAnchorElement).style.transform = 'translateY(-3px)';
              (e.currentTarget as HTMLAnchorElement).style.boxShadow = '0 8px 40px rgba(193, 53, 132, 0.5)';
            }}
            onMouseLeave={(e) => {
              (e.currentTarget as HTMLAnchorElement).style.transform = 'translateY(0)';
              (e.currentTarget as HTMLAnchorElement).style.boxShadow = '0 4px 24px rgba(193, 53, 132, 0.35)';
            }}
          >
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
              <rect width="20" height="20" x="2" y="2" rx="5" ry="5"/>
              <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/>
              <line x1="17.5" x2="17.51" y1="6.5" y2="6.5"/>
            </svg>
            @27elshreif
          </a>
        </div>

        {/* Social icons row */}
        <div className="social-reveal flex items-center justify-center gap-4">
          {SOCIAL_LINKS.map((link) => (
            <a
              key={link.name}
              href={link.href}
              target="_blank"
              rel="noopener noreferrer"
              className="social-btn"
              aria-label={link.ariaLabel}
            >
              {link.icon}
            </a>
          ))}
        </div>

        {/* Gold divider */}
        <div
          className="social-reveal mt-16 h-px"
          style={{ background: 'linear-gradient(90deg, transparent, var(--accent), transparent)' }}
        />
      </div>
    </section>
  );
}