'use client';

import React, { useEffect, useRef, useState } from 'react';

interface Stat {
  value: number;
  suffix: string;
  label: string;
  description: string;
  icon: string;
}

const STATS: Stat[] = [
  { value: 312, suffix: '+', label: 'Graduates', description: 'Students who made history together', icon: '🎓' },
  { value: 4, suffix: ' Years', label: 'Journey', description: 'Of late nights, breakthroughs, and growth', icon: '⏳' },
  { value: 1000, suffix: '+', label: 'Memories', description: 'Captured in photos, etched in hearts', icon: '📸' },
  { value: 2027, suffix: '', label: 'Forever', description: 'The year that defined who we are', icon: '✦' },
];

function useCountUp(target: number, duration: number, start: boolean) {
  const [count, setCount] = useState(0);

  useEffect(() => {
    if (!start) return;
    let startTime: number | null = null;
    const step = (timestamp: number) => {
      if (!startTime) startTime = timestamp;
      const progress = Math.min((timestamp - startTime) / (duration * 1000), 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      setCount(Math.floor(eased * target));
      if (progress < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  }, [target, duration, start]);

  return count;
}

function StatCard({ stat, index, inView }: { stat: Stat; index: number; inView: boolean }) {
  const count = useCountUp(stat.value, 2, inView);

  return (
    <div
      className="stat-card p-6 md:p-8 flex flex-col items-center text-center reveal-up opacity-100"
      style={{ animationDelay: `${index * 0.15}s` }}
    >
      <span className="text-3xl mb-4">{stat.icon}</span>
      <div
        className="font-display font-bold mb-2"
        style={{ fontSize: 'clamp(2.5rem, 6vw, 4rem)', lineHeight: 1, color: 'var(--accent)' }}
      >
        {inView ? count : 0}{stat.suffix}
      </div>
      <p className="font-semibold text-base mb-2" style={{ color: 'var(--foreground)' }}>
        {stat.label}
      </p>
      <p className="text-sm font-light" style={{ color: 'var(--muted-foreground)', lineHeight: 1.6 }}>
        {stat.description}
      </p>
    </div>
  );
}

export default function MemoriesSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const [inView, setInView] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setInView(true);
          observer.disconnect();
        }
      },
      { threshold: 0.3 }
    );

    if (sectionRef.current) observer.observe(sectionRef.current);
    return () => observer.disconnect();
  }, []);

  return (
    <section
      id="memories"
      ref={sectionRef}
      className="relative py-20 px-4 md:px-8 lg:px-12 overflow-hidden"
      style={{ background: 'linear-gradient(180deg, #06101f 0%, #0a1628 50%, #06101f 100%)' }}
    >
      {/* Background decoration */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          backgroundImage: 'radial-gradient(circle at 20% 50%, rgba(201,168,76,0.04) 0%, transparent 60%), radial-gradient(circle at 80% 50%, rgba(184,196,208,0.03) 0%, transparent 60%)',
        }}
      />

      <div className="max-w-7xl mx-auto relative z-10">
        {/* Header */}
        <div className="text-center mb-14">
          <span className="text-eyebrow block mb-3" style={{ color: 'var(--accent)' }}>
            ✦ Our Story in Numbers
          </span>
          <h2
            className="font-display font-bold text-section-title mb-4"
            style={{ color: 'var(--foreground)', lineHeight: 1.1 }}
          >
            The Class of 2027
          </h2>
          <p className="max-w-md mx-auto text-base font-light" style={{ color: 'var(--muted-foreground)', lineHeight: 1.7 }}>
            Behind every number is a face, a story, and a dream that refused to be ordinary.
          </p>
          <div
            className="mt-6 h-px max-w-xs mx-auto"
            style={{ background: 'linear-gradient(90deg, transparent, var(--accent), transparent)' }}
          />
        </div>

        {/* Stats grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
          {STATS.map((stat, i) => (
            <StatCard key={stat.label} stat={stat} index={i} inView={inView} />
          ))}
        </div>

        {/* Quote */}
        <div
          className="mt-16 text-center max-w-2xl mx-auto p-8 rounded-2xl"
          style={{
            background: 'rgba(13, 30, 53, 0.5)',
            border: '1px solid rgba(201, 168, 76, 0.15)',
          }}
        >
          <div className="text-4xl mb-4" style={{ color: 'rgba(201,168,76,0.3)' }}>&ldquo;</div>
          <p
            className="font-display text-xl md:text-2xl font-light italic mb-4"
            style={{ color: 'var(--foreground)', lineHeight: 1.6 }}
          >
            We didn&apos;t just graduate. We transformed.
          </p>
          <p className="text-eyebrow" style={{ color: 'var(--accent)' }}>
            Senior 2027 · El Shreif
          </p>
        </div>
      </div>
    </section>
  );
}