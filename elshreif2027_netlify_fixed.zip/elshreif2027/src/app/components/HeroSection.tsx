'use client';

import React, { useEffect, useRef } from 'react';

interface StarItem {
  size: number;
  top: string;
  left: string;
  duration: number;
  delay: number;
  color: 'gold' | 'blue' | 'silver';
  shape: 'star4' | 'star5' | 'star6';
}

interface DiscoItem {
  size: number;
  top: string;
  left: string;
  floatDur: number;
  floatDelay: number;
  ropeLen: number;
}

const STARS: StarItem[] = [
  { size: 38, top: '12%', left: '4%', duration: 3.5, delay: 0, color: 'gold', shape: 'star5' },
  { size: 28, top: '28%', left: '9%', duration: 4.2, delay: 0.5, color: 'blue', shape: 'star4' },
  { size: 22, top: '55%', left: '3%', duration: 3.8, delay: 1.0, color: 'gold', shape: 'star5' },
  { size: 32, top: '72%', left: '7%', duration: 4.0, delay: 0.3, color: 'blue', shape: 'star6' },
  { size: 18, top: '85%', left: '14%', duration: 3.2, delay: 1.5, color: 'gold', shape: 'star4' },
  { size: 42, top: '90%', left: '28%', duration: 4.5, delay: 0.8, color: 'gold', shape: 'star5' },
  { size: 26, top: '78%', left: '42%', duration: 3.6, delay: 0.2, color: 'blue', shape: 'star4' },
  { size: 20, top: '88%', left: '58%', duration: 4.1, delay: 1.2, color: 'silver', shape: 'star5' },
  { size: 34, top: '82%', left: '72%', duration: 3.9, delay: 0.6, color: 'gold', shape: 'star6' },
  { size: 24, top: '75%', left: '85%', duration: 4.3, delay: 0.9, color: 'blue', shape: 'star4' },
  { size: 30, top: '60%', left: '93%', duration: 3.4, delay: 1.8, color: 'blue', shape: 'star5' },
  { size: 22, top: '40%', left: '96%', duration: 4.0, delay: 0.4, color: 'gold', shape: 'star4' },
  { size: 18, top: '20%', left: '92%', duration: 3.7, delay: 1.1, color: 'blue', shape: 'star6' },
  { size: 28, top: '8%', left: '78%', duration: 4.4, delay: 0.7, color: 'gold', shape: 'star5' },
  { size: 16, top: '5%', left: '55%', duration: 3.3, delay: 2.0, color: 'blue', shape: 'star4' },
  { size: 20, top: '10%', left: '22%', duration: 4.2, delay: 0.1, color: 'gold', shape: 'star5' },
];

const DISCOS: DiscoItem[] = [
  { size: 72, top: '2%', left: '62%', floatDur: 6, floatDelay: 0, ropeLen: 80 },
  { size: 56, top: '2%', left: '72%', floatDur: 7.5, floatDelay: 1.2, ropeLen: 60 },
  { size: 88, top: '2%', left: '82%', floatDur: 5.5, floatDelay: 0.5, ropeLen: 100 },
  { size: 48, top: '2%', left: '90%', floatDur: 8, floatDelay: 2.0, ropeLen: 50 },
];

function StarSVG({ color, shape, size }: { color: string; shape: string; size: number }) {
  const fills: Record<string, string> = {
    gold: 'url(#starGold)',
    blue: 'url(#starBlue)',
    silver: 'url(#starSilver)',
  };
  const fill = fills[color] || fills.gold;

  if (shape === 'star4') {
    // 4-pointed star
    const s = size / 2;
    const pts = `${s},0 ${s * 0.3},${s * 0.3} 0,${s} ${s * 0.3 * -1 + s},${s * 0.3} ${s * 2},${s} ${s + s * 0.3},${s + s * 0.3} ${s},${s * 2} ${s - s * 0.3},${s + s * 0.3}`;
    return (
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} style={{ display: 'block' }}>
        <defs>
          <linearGradient id="starGold" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#E8C870" />
            <stop offset="100%" stopColor="#A07830" />
          </linearGradient>
          <linearGradient id="starBlue" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#4a7fc1" />
            <stop offset="100%" stopColor="#1a3a6e" />
          </linearGradient>
          <linearGradient id="starSilver" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#e0e8f0" />
            <stop offset="100%" stopColor="#8899AA" />
          </linearGradient>
        </defs>
        <polygon points={pts} fill={fill} opacity="0.9" />
      </svg>
    );
  }

  // 5-pointed or 6-pointed star using path
  const points = shape === 'star6' ? 6 : 5;
  const cx = size / 2, cy = size / 2;
  const outerR = size / 2;
  const innerR = shape === 'star6' ? outerR * 0.55 : outerR * 0.4;
  const totalPts = points * 2;
  const ptArr: string[] = [];
  for (let i = 0; i < totalPts; i++) {
    const angle = (Math.PI / points) * i - Math.PI / 2;
    const r = i % 2 === 0 ? outerR : innerR;
    ptArr.push(`${cx + r * Math.cos(angle)},${cy + r * Math.sin(angle)}`);
  }
  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} style={{ display: 'block' }}>
      <defs>
        <linearGradient id="starGold" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#E8C870" />
          <stop offset="100%" stopColor="#A07830" />
        </linearGradient>
        <linearGradient id="starBlue" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#5a8fd4" />
          <stop offset="100%" stopColor="#1a3a6e" />
        </linearGradient>
        <linearGradient id="starSilver" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#e0e8f0" />
          <stop offset="100%" stopColor="#8899AA" />
        </linearGradient>
      </defs>
      <polygon points={ptArr.join(' ')} fill={fill} opacity="0.92" />
    </svg>
  );
}

function DiscoBall({ size, ropeLen }: { size: number; ropeLen: number }) {
  return (
    <svg width={size} height={size + ropeLen} viewBox={`0 0 ${size} ${size + ropeLen}`} style={{ display: 'block' }}>
      <defs>
        <radialGradient id="discoGrad" cx="35%" cy="30%" r="65%">
          <stop offset="0%" stopColor="#ffffff" stopOpacity="1" />
          <stop offset="25%" stopColor="#d0dce8" stopOpacity="1" />
          <stop offset="55%" stopColor="#8899AA" stopOpacity="1" />
          <stop offset="80%" stopColor="#4a5f72" stopOpacity="1" />
          <stop offset="100%" stopColor="#1e2e3e" stopOpacity="1" />
        </radialGradient>
        <filter id="discoGlow">
          <feGaussianBlur stdDeviation="3" result="blur" />
          <feMerge>
            <feMergeNode in="blur" />
            <feMergeNode in="SourceGraphic" />
          </feMerge>
        </filter>
      </defs>
      {/* Rope */}
      <line x1={size / 2} y1="0" x2={size / 2} y2={ropeLen} stroke="#8899AA" strokeWidth="1.5" opacity="0.6" />
      {/* Ball */}
      <circle cx={size / 2} cy={ropeLen + size / 2} r={size / 2 - 2} fill="url(#discoGrad)" filter="url(#discoGlow)" />
      {/* Tile grid lines */}
      {Array.from({ length: 6 }).map((_, row) =>
        Array.from({ length: 8 }).map((_, col) => {
          const tileW = (size - 4) / 8;
          const tileH = (size - 4) / 6;
          const x = 2 + col * tileW;
          const y = ropeLen + 2 + row * tileH;
          return (
            <rect
              key={`${row}-${col}`}
              x={x}
              y={y}
              width={tileW - 1}
              height={tileH - 1}
              fill="none"
              stroke="rgba(255,255,255,0.15)"
              strokeWidth="0.5"
              rx="0.5"
            />
          );
        })
      )}
      {/* Highlight */}
      <ellipse cx={size / 2 - size * 0.12} cy={ropeLen + size * 0.28} rx={size * 0.12} ry={size * 0.08} fill="rgba(255,255,255,0.5)" />
    </svg>
  );
}

export default function HeroSection() {
  const heroRef = useRef<HTMLElement>(null);
  const badgeRef = useRef<HTMLDivElement>(null);
  const balloonRef = useRef<HTMLDivElement>(null);
  const paperRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const initGsap = async () => {
      const gsapModule = await import('gsap');
      const gsap = gsapModule.gsap;

      const tl = gsap.timeline({ defaults: { ease: 'power4.out' } });

      if (paperRef.current) {
        tl.fromTo(paperRef.current, { scaleY: 0, opacity: 0 }, { scaleY: 1, opacity: 1, duration: 1.2, ease: 'power3.out' }, 0);
      }
      if (balloonRef.current) {
        tl.fromTo(balloonRef.current, { y: -120, opacity: 0 }, { y: 0, opacity: 1, duration: 1.6, ease: 'bounce.out' }, 0.3);
      }
      if (badgeRef.current) {
        tl.fromTo(badgeRef.current, { scale: 0.4, opacity: 0, rotation: -20 }, { scale: 1, opacity: 1, rotation: 0, duration: 1.4, ease: 'back.out(1.6)' }, 0.7);
      }
      tl.fromTo('.hero-sub-text', { opacity: 0, y: 20 }, { opacity: 1, y: 0, duration: 1.0, stagger: 0.15 }, 1.2);
      tl.fromTo('.disco-wrap', { y: -60, opacity: 0 }, { y: 0, opacity: 1, duration: 1.2, stagger: 0.12, ease: 'power2.out' }, 0.2);
      tl.fromTo('.star-item', { scale: 0, opacity: 0 }, { scale: 1, opacity: 1, duration: 0.6, stagger: 0.04, ease: 'back.out(2)' }, 0.4);
    };
    initGsap();

    const handleMouseMove = (e: MouseEvent) => {
      if (!heroRef.current) return;
      const { clientX, clientY } = e;
      const { innerWidth, innerHeight } = window;
      const xR = (clientX / innerWidth - 0.5) * 2;
      const yR = (clientY / innerHeight - 0.5) * 2;
      heroRef.current.querySelectorAll('[data-parallax]').forEach((el) => {
        const speed = parseFloat((el as HTMLElement).dataset.parallax || '1');
        (el as HTMLElement).style.transform = `translate(${xR * speed * 12}px, ${yR * speed * 8}px)`;
      });
    };
    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  return (
    <section
      ref={heroRef}
      id="hero"
      className="relative min-h-screen flex flex-col items-center justify-center overflow-hidden"
      style={{ background: '#0d1b35' }}
    >
      {/* ── Dark navy background texture ── */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          backgroundImage: `
            radial-gradient(ellipse 80% 60% at 50% 0%, rgba(30,60,110,0.5) 0%, transparent 70%),
            radial-gradient(ellipse 60% 40% at 10% 80%, rgba(10,30,70,0.6) 0%, transparent 60%),
            radial-gradient(ellipse 50% 50% at 90% 90%, rgba(10,30,70,0.5) 0%, transparent 60%)
          `,
        }}
      />

      {/* ── Scattered Stars (on dark navy, outside torn paper) ── */}
      {STARS.map((star, i) => (
        <div
          key={i}
          className="star-item absolute pointer-events-none"
          data-parallax={i % 3 === 0 ? '0.8' : i % 3 === 1 ? '1.2' : '0.5'}
          style={{
            top: star.top,
            left: star.left,
            animation: `starFloat ${star.duration}s ease-in-out infinite`,
            animationDelay: `${star.delay}s`,
            zIndex: 3,
          }}
        >
          <StarSVG color={star.color} shape={star.shape} size={star.size} />
        </div>
      ))}

      {/* ── Hanging Disco Balls (top right area) ── */}
      {DISCOS.map((disco, i) => (
        <div
          key={i}
          className="disco-wrap absolute pointer-events-none"
          style={{
            top: 0,
            left: disco.left,
            animation: `discoFloat ${disco.floatDur}s ease-in-out infinite`,
            animationDelay: `${disco.floatDelay}s`,
            zIndex: 4,
            transformOrigin: 'top center',
          }}
        >
          <DiscoBall size={disco.size} ropeLen={disco.ropeLen} />
        </div>
      ))}

      {/* ── Torn Paper Middle Layer ── */}
      <div
        ref={paperRef}
        className="absolute inset-x-0 pointer-events-none"
        style={{
          top: '18%',
          bottom: '18%',
          zIndex: 2,
          transformOrigin: 'center center',
        }}
      >
        {/* Top torn edge */}
        <svg
          viewBox="0 0 1440 120"
          preserveAspectRatio="none"
          className="absolute top-0 left-0 w-full"
          style={{ height: '120px', display: 'block' }}
        >
          <path
            d="M0,120 L0,60
              C20,45 45,75 70,55 C95,35 120,65 150,48
              C180,30 205,62 235,44 C265,26 290,58 320,40
              C350,22 375,56 405,38 C435,20 460,54 490,36
              C520,18 545,52 575,35 C605,18 630,50 660,33
              C690,16 715,48 745,32 C775,16 800,46 830,30
              C860,14 885,46 915,28 C945,10 970,44 1000,27
              C1030,10 1055,42 1085,26 C1115,10 1140,40 1170,24
              C1200,8 1225,38 1255,22 C1285,6 1310,36 1340,20
              C1370,4 1400,34 1440,18
              L1440,120 Z"
            fill="#e8dfc8"
          />
        </svg>

        {/* Paper body */}
        <div
          className="absolute left-0 right-0"
          style={{
            top: '100px',
            bottom: '100px',
            background: 'linear-gradient(180deg, #e8dfc8 0%, #ede4cc 40%, #e5dbc0 70%, #ddd3b5 100%)',
          }}
        />

        {/* Bottom torn edge */}
        <svg
          viewBox="0 0 1440 120"
          preserveAspectRatio="none"
          className="absolute bottom-0 left-0 w-full"
          style={{ height: '120px', display: 'block' }}
        >
          <path
            d="M0,0 L0,60
              C25,75 50,45 80,62 C110,78 135,48 165,65
              C195,82 220,50 250,68 C280,86 305,52 335,70
              C365,88 390,54 420,72 C450,90 475,56 505,74
              C535,92 560,58 590,76 C620,94 645,60 675,78
              C705,96 730,62 760,80 C790,98 815,64 845,82
              C875,100 900,66 930,84 C960,102 985,68 1015,86
              C1045,104 1070,70 1100,88 C1130,106 1155,72 1185,90
              C1215,108 1240,74 1270,92 C1300,110 1325,76 1355,94
              C1385,112 1410,78 1440,96
              L1440,0 Z"
            fill="#e8dfc8"
          />
        </svg>
      </div>

      {/* ── Main Content (on top of torn paper) ── */}
      <div className="relative flex flex-col items-center text-center px-4 pt-24 pb-20" style={{ zIndex: 10 }}>

        {/* Silver Balloon "2027" */}
        <div ref={balloonRef} className="mb-2" data-parallax="0.6">
          <svg
            viewBox="0 0 520 160"
            style={{ width: 'clamp(260px, 45vw, 520px)', height: 'auto', display: 'block' }}
            aria-label="2027 balloon typography"
          >
            <defs>
              <radialGradient id="balloonGrad" cx="35%" cy="30%" r="65%">
                <stop offset="0%" stopColor="#ffffff" />
                <stop offset="20%" stopColor="#e8eef4" />
                <stop offset="50%" stopColor="#b0bec8" />
                <stop offset="80%" stopColor="#6e8090" />
                <stop offset="100%" stopColor="#3a4e5e" />
              </radialGradient>
              <filter id="balloonShadow" x="-10%" y="-10%" width="120%" height="130%">
                <feDropShadow dx="0" dy="6" stdDeviation="8" floodColor="rgba(0,0,0,0.35)" />
              </filter>
              <filter id="balloonGlow">
                <feGaussianBlur stdDeviation="4" result="blur" />
                <feMerge>
                  <feMergeNode in="blur" />
                  <feMergeNode in="SourceGraphic" />
                </feMerge>
              </filter>
            </defs>
            {/* Balloon strings */}
            <line x1="65" y1="148" x2="65" y2="158" stroke="#8899AA" strokeWidth="1.5" />
            <line x1="195" y1="148" x2="195" y2="158" stroke="#8899AA" strokeWidth="1.5" />
            <line x1="325" y1="148" x2="325" y2="158" stroke="#8899AA" strokeWidth="1.5" />
            <line x1="455" y1="148" x2="455" y2="158" stroke="#8899AA" strokeWidth="1.5" />
            {/* "2" balloon */}
            <rect x="10" y="10" width="110" height="138" rx="28" ry="28" fill="url(#balloonGrad)" filter="url(#balloonShadow)" />
            <text x="65" y="98" textAnchor="middle" fill="rgba(255,255,255,0.9)" fontSize="90" fontFamily="Arial Black, sans-serif" fontWeight="900" filter="url(#balloonGlow)">2</text>
            <ellipse cx="38" cy="38" rx="16" ry="10" fill="rgba(255,255,255,0.45)" transform="rotate(-20,38,38)" />
            {/* "0" balloon */}
            <rect x="140" y="10" width="110" height="138" rx="28" ry="28" fill="url(#balloonGrad)" filter="url(#balloonShadow)" />
            <text x="195" y="98" textAnchor="middle" fill="rgba(255,255,255,0.9)" fontSize="90" fontFamily="Arial Black, sans-serif" fontWeight="900" filter="url(#balloonGlow)">0</text>
            <ellipse cx="168" cy="38" rx="16" ry="10" fill="rgba(255,255,255,0.45)" transform="rotate(-20,168,38)" />
            {/* "2" balloon */}
            <rect x="270" y="10" width="110" height="138" rx="28" ry="28" fill="url(#balloonGrad)" filter="url(#balloonShadow)" />
            <text x="325" y="98" textAnchor="middle" fill="rgba(255,255,255,0.9)" fontSize="90" fontFamily="Arial Black, sans-serif" fontWeight="900" filter="url(#balloonGlow)">2</text>
            <ellipse cx="298" cy="38" rx="16" ry="10" fill="rgba(255,255,255,0.45)" transform="rotate(-20,298,38)" />
            {/* "7" balloon */}
            <rect x="400" y="10" width="110" height="138" rx="28" ry="28" fill="url(#balloonGrad)" filter="url(#balloonShadow)" />
            <text x="455" y="98" textAnchor="middle" fill="rgba(255,255,255,0.9)" fontSize="90" fontFamily="Arial Black, sans-serif" fontWeight="900" filter="url(#balloonGlow)">7</text>
            <ellipse cx="428" cy="38" rx="16" ry="10" fill="rgba(255,255,255,0.45)" transform="rotate(-20,428,38)" />
          </svg>
        </div>

        {/* "ONE MORE YEAR LEFT" tagline */}
        <p
          className="hero-sub-text font-display font-bold tracking-widest mb-6"
          style={{
            color: '#2a3a5e',
            fontSize: 'clamp(0.85rem, 2.5vw, 1.3rem)',
            letterSpacing: '0.25em',
            opacity: 0,
          }}
        >
          ONE MORE YEAR LEFT
        </p>

        {/* Circular Badge */}
        <div ref={badgeRef} className="my-4" data-parallax="1.0" style={{ opacity: 0 }}>
          <svg
            viewBox="0 0 260 260"
            style={{ width: 'clamp(180px, 28vw, 260px)', height: 'clamp(180px, 28vw, 260px)', filter: 'drop-shadow(0 8px 32px rgba(0,0,0,0.5))' }}
            aria-label="Senior 2027 El Shreif badge"
          >
            <defs>
              <linearGradient id="badgeGold" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#A07830" />
                <stop offset="40%" stopColor="#C9A84C" />
                <stop offset="70%" stopColor="#E8C870" />
                <stop offset="100%" stopColor="#C9A84C" />
              </linearGradient>
              <linearGradient id="badgeGold2" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="#A07830" />
                <stop offset="50%" stopColor="#E8C870" />
                <stop offset="100%" stopColor="#A07830" />
              </linearGradient>
              <linearGradient id="badgeBg" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#0a1628" />
                <stop offset="100%" stopColor="#06101f" />
              </linearGradient>
              <linearGradient id="bannerGold" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="#8a6520" />
                <stop offset="30%" stopColor="#C9A84C" />
                <stop offset="70%" stopColor="#E8C870" />
                <stop offset="100%" stopColor="#8a6520" />
              </linearGradient>
              <filter id="badgeGlow">
                <feGaussianBlur stdDeviation="2.5" result="blur" />
                <feMerge>
                  <feMergeNode in="blur" />
                  <feMergeNode in="SourceGraphic" />
                </feMerge>
              </filter>
              <path id="circleTextPath" d="M 130,130 m -100,0 a 100,100 0 1,1 200,0 a 100,100 0 1,1 -200,0" fill="none" />
            </defs>

            {/* Outer decorative ring */}
            <circle cx="130" cy="130" r="126" fill="none" stroke="url(#badgeGold)" strokeWidth="1" opacity="0.5" />
            {/* Main circle */}
            <circle cx="130" cy="130" r="120" fill="url(#badgeBg)" stroke="url(#badgeGold)" strokeWidth="3" filter="url(#badgeGlow)" />
            {/* Inner ring */}
            <circle cx="130" cy="130" r="112" fill="none" stroke="url(#badgeGold2)" strokeWidth="0.8" strokeDasharray="5 3" />

            {/* Circular spinning text */}
            <text style={{ animation: 'badgeSpin 20s linear infinite', transformOrigin: '130px 130px' }}>
              <textPath href="#circleTextPath" startOffset="0%">
                <tspan fill="url(#badgeGold2)" fontSize="10.5" fontFamily="var(--font-dm-sans)" fontWeight="700" letterSpacing="3.5">
                  ✦ SENIOR 2027 ✦ EL SHREIF ✦ SENIOR 2027 ✦ EL SHREIF ✦
                </tspan>
              </textPath>
            </text>

            {/* Shield shape */}
            <path
              d="M130,52 L158,65 L158,100 Q158,125 130,138 Q102,125 102,100 L102,65 Z"
              fill="url(#badgeBg)"
              stroke="url(#badgeGold)"
              strokeWidth="1.5"
            />
            {/* S letter in shield */}
            <text x="130" y="108" textAnchor="middle" fill="url(#badgeGold)" fontSize="30" fontFamily="var(--font-fraunces)" fontWeight="900" filter="url(#badgeGlow)">S</text>

            {/* Laurel branches */}
            {/* Left branch */}
            <g transform="translate(130,130)" opacity="0.85">
              {[-50,-42,-34,-26,-18].map((angle, i) => (
                <ellipse
                  key={`l${i}`}
                  cx={-38 + i * 4}
                  cy={-8 + i * 2}
                  rx="7"
                  ry="4"
                  fill="url(#badgeGold)"
                  transform={`rotate(${angle + 180},${-38 + i * 4},${-8 + i * 2})`}
                  opacity="0.8"
                />
              ))}
              {/* Right branch */}
              {[-50,-42,-34,-26,-18].map((angle, i) => (
                <ellipse
                  key={`r${i}`}
                  cx={38 - i * 4}
                  cy={-8 + i * 2}
                  rx="7"
                  ry="4"
                  fill="url(#badgeGold)"
                  transform={`rotate(${-(angle + 180)},${38 - i * 4},${-8 + i * 2})`}
                  opacity="0.8"
                />
              ))}
            </g>

            {/* SENIOR text */}
            <text x="130" y="158" textAnchor="middle" fill="url(#badgeGold)" fontSize="16" fontFamily="var(--font-dm-sans)" fontWeight="800" letterSpacing="4" filter="url(#badgeGlow)">SENIOR</text>

            {/* 2027 text */}
            <text x="130" y="176" textAnchor="middle" fill="#B8C4D0" fontSize="13" fontFamily="var(--font-dm-sans)" fontWeight="700" letterSpacing="3">2027</text>

            {/* El Shreif banner */}
            <path d="M90,188 Q130,182 170,188 L168,202 Q130,196 92,202 Z" fill="url(#bannerGold)" />
            <text x="130" y="199" textAnchor="middle" fill="#06101f" fontSize="11" fontFamily="var(--font-fraunces)" fontWeight="800" letterSpacing="1">El Shreif</text>

            {/* Bottom decorative dots */}
            <circle cx="110" cy="212" r="2.5" fill="url(#badgeGold)" />
            <circle cx="130" cy="215" r="3" fill="url(#badgeGold)" />
            <circle cx="150" cy="212" r="2.5" fill="url(#badgeGold)" />
          </svg>
        </div>

        {/* CTA Buttons */}
        <div className="hero-sub-text mt-8 flex flex-wrap gap-4 items-center justify-center" style={{ opacity: 0 }}>
          <a
            href="#gallery"
            className="px-8 py-3.5 rounded-full font-semibold text-sm transition-all duration-300"
            style={{
              background: 'linear-gradient(135deg, var(--gold-dark), var(--accent), var(--gold-light))',
              color: '#06101f',
              boxShadow: '0 4px 24px rgba(201,168,76,0.35)',
            }}
            onMouseEnter={(e) => {
              (e.currentTarget as HTMLAnchorElement).style.transform = 'translateY(-2px)';
              (e.currentTarget as HTMLAnchorElement).style.boxShadow = '0 8px 36px rgba(201,168,76,0.55)';
            }}
            onMouseLeave={(e) => {
              (e.currentTarget as HTMLAnchorElement).style.transform = 'translateY(0)';
              (e.currentTarget as HTMLAnchorElement).style.boxShadow = '0 4px 24px rgba(201,168,76,0.35)';
            }}
          >
            View Gallery
          </a>
          <a
            href="https://www.instagram.com/27elshreif"
            target="_blank"
            rel="noopener noreferrer"
            className="px-8 py-3.5 rounded-full font-semibold text-sm transition-all duration-300"
            style={{
              border: '1.5px solid rgba(201,168,76,0.4)',
              color: 'var(--accent)',
            }}
            onMouseEnter={(e) => {
              (e.currentTarget as HTMLAnchorElement).style.background = 'rgba(201,168,76,0.1)';
              (e.currentTarget as HTMLAnchorElement).style.transform = 'translateY(-2px)';
            }}
            onMouseLeave={(e) => {
              (e.currentTarget as HTMLAnchorElement).style.background = 'transparent';
              (e.currentTarget as HTMLAnchorElement).style.transform = 'translateY(0)';
            }}
          >
            @27elshreif
          </a>
        </div>

        {/* Scroll indicator */}
        <div className="hero-sub-text mt-14 flex flex-col items-center gap-2" style={{ opacity: 0 }}>
          <span className="text-eyebrow" style={{ color: 'rgba(184,196,208,0.6)' }}>Scroll to explore</span>
          <div className="w-px h-10 relative overflow-hidden" style={{ background: 'rgba(201,168,76,0.15)' }}>
            <div
              className="absolute top-0 left-0 w-full"
              style={{
                height: '40%',
                background: 'linear-gradient(to bottom, var(--accent), transparent)',
                animation: 'float 2s ease-in-out infinite',
              }}
            />
          </div>
        </div>
      </div>
    </section>
  );
}